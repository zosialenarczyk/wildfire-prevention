To view Readme.txt please visit https://firms.modaps.eosdis.nasa.gov/download/Readme.txt
